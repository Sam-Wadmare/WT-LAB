const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'data.txt');

// ✅ CREATE
function createFile(content) {
  fs.writeFileSync(filePath, content, 'utf8');
  console.log('File created successfully.');
}

// 📖 READ
function readFile() {
  if (fs.existsSync(filePath)) {
    const data = fs.readFileSync(filePath, 'utf8');
    console.log('File content:', data);
  } else {
    console.log('File does not exist.');
  }
}

// 🔄 UPDATE
function updateFile(newContent) {
  if (fs.existsSync(filePath)) {
    fs.appendFileSync(filePath, '\n' + newContent, 'utf8');
    console.log('File updated successfully.');
  } else {
    console.log('File does not exist to update.');
  }
}

// ❌ DELETE
function deleteFile() {
  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
    console.log('File deleted successfully.');
  } else {
    console.log('File does not exist to delete.');
  }
}

// 🎯 Call operations here to test

// 1. Create
createFile("This is the first content.");

// 2. Read
readFile();

// 3. Update
updateFile("This is additional content.");

// 4. Read again to verify update
readFile();

// 5. Delete
deleteFile();
