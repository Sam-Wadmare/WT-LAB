const {add, subtract, multi, divide,PI, E} = require("./modules/math.js");
console.log(add(2,3));
console.log(subtract(2,3));
console.log(multi(2,3));
console.log(divide(6,3));
console.log(PI);
console.log(E);
console.log("program ended!!");