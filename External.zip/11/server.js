const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./db');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

// Show all employee data
app.get('/all', (req, res) => {
  db.query('SELECT * FROM employees', (err, results) => {
    if (err) return res.send('Error fetching data');
    res.render('result', { employees: results });
  });
});

// Search by first name
app.post('/search', (req, res) => {
  const name = req.body.first_name;
  db.query('SELECT * FROM employees WHERE first_name = ?', [name], (err, results) => {
    if (err) return res.send('Error searching data');
    res.render('result', { employees: results });
  });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
