CREATE DATABASE company_db;

USE company_db;

CREATE TABLE employees (
  id INT PRIMARY KEY,
  first_name VARCHAR(50),
  last_name VARCHAR(50),
  department VARCHAR(50),
  salary INT
);

-- Sample data
INSERT INTO employees VALUES 
(1, 'John', 'Doe', 'IT', 50000),
(2, 'Alice', 'Smith', 'HR', 45000),
(3, 'Bob', 'Brown', 'Finance', 60000);
