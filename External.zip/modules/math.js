function add( a, b) {
    return a + b;
}
function subtract( a, b) {
    return a - b;
}   
function multi(a,b) {
    return a*b;
}
function divide(a,b) {
    return a/b;
}
 const PI = 3.14;
    const E = 2.71;

module.exports = {add, subtract, multi, divide, PI, E};