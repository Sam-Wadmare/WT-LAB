const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./db');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Handle form submission
app.post('/submit', (req, res) => {
  const { name, email, age, course } = req.body;

  const sql = 'INSERT INTO students (name, email, age, course) VALUES (?, ?, ?, ?)';
  db.query(sql, [name, email, age, course], (err, result) => {
    if (err) {
      console.error('Error inserting data:', err);
      return res.send('Error saving student data.');
    }
    res.send('<h3>Student information saved successfully!</h3><a href="/">Go back</a>');
  });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
