package com.example;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

@SuppressWarnings("serial")
public class StudentRegistrationServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String rollno = request.getParameter("rollno");
        String firstname = request.getParameter("firstname");
        String lastname = request.getParameter("lastname");
        String year = request.getParameter("year");
        String gender = request.getParameter("gender");
        String[] qualifications = request.getParameterValues("qualification");

        String qualification = "";
        if (qualifications != null) {
            qualification = String.join(", ", qualifications);
        }

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to database
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/student_db", "root", "Purva@1209");

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO students (rollno, firstname, lastname, year, gender, qualification) VALUES (?, ?, ?, ?, ?, ?)");

            ps.setString(1, rollno);
            ps.setString(2, firstname);
            ps.setString(3, lastname);
            ps.setString(4, year);
            ps.setString(5, gender);
            ps.setString(6, qualification);

            int i = ps.executeUpdate();

            if (i > 0) {
                out.println("<h2>Successfully Registered!</h2>");
                out.println("<h3>Student Details:</h3>");
                out.println("<p>Roll No: " + rollno + "</p>");
                out.println("<p>Name: " + firstname + " " + lastname + "</p>");
                out.println("<p>Academic Year: " + year + "</p>");
                out.println("<p>Gender: " + gender + "</p>");
                out.println("<p>Qualifications: " + qualification + "</p>");
            } else {
                out.println("<h3>Registration Failed</h3>");
            }

            con.close();
        } catch (Exception e) {
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }

        out.close();
    }
}
