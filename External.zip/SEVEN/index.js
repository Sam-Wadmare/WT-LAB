const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./db');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Get student info by ID
app.get('/get', (req, res) => {
  const id = req.query.id;
  const query = 'SELECT * FROM students WHERE id = ?';

  db.query(query, [id], (err, results) => {
    if (err) return res.send('Database error');
    if (results.length === 0) return res.send(`<h3>No student found with ID ${id}</h3><a href="/">Back</a>`);

    const student = results[0];
    res.send(`
      <h3>Student Info</h3>
      <p>ID: ${student.id}</p>
      <p>Name: ${student.name}</p>
      <p>Email: ${student.email}</p>
      <p>Age: ${student.age}</p>
      <p>Course: ${student.course}</p>
      <a href="/">Back</a>
    `);
  });
});

// Update student info
app.post('/update', (req, res) => {
  const { id, name, email, age, course } = req.body;
  const query = 'UPDATE students SET name = ?, email = ?, age = ?, course = ? WHERE id = ?';

  db.query(query, [name, email, age, course, id], (err, result) => {
    if (err) return res.send('Update failed');
    if (result.affectedRows === 0) return res.send(`<h3>No student found with ID ${id}</h3><a href="/">Back</a>`);

    res.send(`<h3>Student ID ${id} updated successfully!</h3><a href="/">Back</a>`);
  });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
