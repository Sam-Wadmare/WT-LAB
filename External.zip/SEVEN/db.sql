CREATE DATABASE student_db;

USE student_db;

CREATE TABLE students (
  id INT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100),
  age INT,
  course VARCHAR(100)
);

-- Sample data:
INSERT INTO students (id, name, email, age, course)
VALUES (1, 'John Doe', 'john@example.com', 20, 'Computer Science');
