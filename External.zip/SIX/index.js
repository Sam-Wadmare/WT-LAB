const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./db');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// GET: Retrieve student by ID
app.get('/get', (req, res) => {
  const { id } = req.query;

  db.query('SELECT * FROM students WHERE id = ?', [id], (err, results) => {
    if (err) return res.status(500).send('Database error');

    if (results.length === 0) {
      return res.send(`<h3>No student found with ID ${id}</h3><a href="/">Go Back</a>`);
    }

    const student = results[0];
    res.send(`
      <h3>Student Found:</h3>
      <p>Name: ${student.name}</p>
      <p>Email: ${student.email}</p>
      <p>Age: ${student.age}</p>
      <p>Course: ${student.course}</p>
      <a href="/">Go Back</a>
    `);
  });
});

// POST: Delete student by ID
app.post('/delete', (req, res) => {
  const { id } = req.body;

  db.query('DELETE FROM students WHERE id = ?', [id], (err, result) => {
    if (err) return res.status(500).send('Database error');

    if (result.affectedRows === 0) {
      return res.send(`<h3>No student found with ID ${id}</h3><a href="/">Go Back</a>`);
    }

    res.send(`<h3>Student with ID ${id} deleted successfully.</h3><a href="/">Go Back</a>`);
  });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
