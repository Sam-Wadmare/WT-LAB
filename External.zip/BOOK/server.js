const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// In-memory array to store books
let books = [];

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public'));

// Add a new book
app.post('/books', (req, res) => {
  const { title, author, isbn, year } = req.body;

  if (!title || !author || !isbn || !year) {
    return res.status(400).send('All fields are required.');
  }

  // Check if ISBN already exists
  const exists = books.some(book => book.isbn === isbn);
  if (exists) return res.status(409).send('Book with this ISBN already exists.');

  books.push({ title, author, isbn, year });
  res.send('Book added successfully');
});

// Retrieve all books
app.get('/books', (req, res) => {
  res.json(books);
});

// Delete a book by ISBN
app.delete('/books/:isbn', (req, res) => {
  const isbn = req.params.isbn;
  const initialLength = books.length;
  books = books.filter(book => book.isbn !== isbn);

  if (books.length === initialLength) {
    return res.status(404).send('Book not found');
  }

  res.send('Book deleted successfully');
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
