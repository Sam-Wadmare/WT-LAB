const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./db');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Retrieve student info
app.get('/get', (req, res) => {
  const id = req.query.id;
  const query = 'SELECT * FROM students WHERE id = ?';

  db.query(query, [id], (err, results) => {
    if (err) return res.send('Database error');
    if (results.length === 0) return res.send(`<h3>No student found with ID ${id}</h3><a href="/">Back</a>`);

    const student = results[0];
    res.send(`
      <h3>Student Info</h3>
      <p>ID: ${student.id}</p>
      <p>Name: ${student.name}</p>
      <p>Email: ${student.email}</p>
      <p>Age: ${student.age}</p>
      <p>Course: ${student.course}</p>
      <a href="/">Back</a>
    `);
  });
});

// Delete student info
app.post('/delete', (req, res) => {
  const id = req.body.id;
  const query = 'DELETE FROM students WHERE id = ?';

  db.query(query, [id], (err, result) => {
    if (err) return res.send('Error deleting student');
    if (result.affectedRows === 0) return res.send(`<h3>No student found with ID ${id}</h3><a href="/">Back</a>`);

    res.send(`<h3>Student ID ${id} deleted successfully!</h3><a href="/">Back</a>`);
  });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
